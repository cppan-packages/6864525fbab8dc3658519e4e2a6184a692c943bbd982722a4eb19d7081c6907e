/* $OpenBSD: rc4_locl.h,v 1.4 2014/07/11 08:44:49 jsing Exp $ */

#ifndef HEADER_RC4_LOCL_H
#define HEADER_RC4_LOCL_H
#endif
